import React from 'react';
function App() {
  return <div>Welcome to Admin Panel</div>;
}
export default App;