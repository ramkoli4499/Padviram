# Padviram Project

Full-stack setup with frontend, backend, and optional admin panel.
